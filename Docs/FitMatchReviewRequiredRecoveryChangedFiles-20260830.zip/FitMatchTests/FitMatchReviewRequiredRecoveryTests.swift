import Foundation
import Testing
@testable import FitMatch

struct FitMatchReviewRequiredRecoveryTests {
    @Test func recoveryContractKeepsKnownFactsAndOnlyBoundedServerCandidates() async throws {
        let fixture = try RecoveryContractFixture()
        let remote = RecoveryTransportStub(
            contract: fixture.contract,
            saved: fixture.savedMutation,
            cleared: fixture.clearedMutation
        )
        let coordinator = FitMatchServerAuthorityCoordinator(remote: remote)

        let contract = try await coordinator.classificationRecoveryOptions(
            productID: fixture.productID
        )

        #expect(contract.isSafelyRecoverable)
        #expect(contract.fixedFacts.audienceCode == "MEN")
        #expect(contract.fixedFacts.categoryCode == "tops")
        #expect(contract.fixedFacts.sleeveLengthCode == "short_sleeve")
        #expect(contract.fixedFacts.garmentTypeCode == nil)
        #expect(contract.unknownFields == [.garmentType])
        #expect(contract.candidates.count == 3)
        #expect(Set(contract.candidates.map(\.garmentTypeCode)) == [
            "tshirt", "polo_shirt", "shirt_blouse"
        ])
    }

    @Test func coordinatorSendsOnlyOpaqueCandidateAndServerContractProvenance() async throws {
        let fixture = try RecoveryContractFixture()
        let remote = RecoveryTransportStub(
            contract: fixture.contract,
            saved: fixture.savedMutation,
            cleared: fixture.clearedMutation
        )
        let coordinator = FitMatchServerAuthorityCoordinator(remote: remote)
        let contract = try await coordinator.classificationRecoveryOptions(
            productID: fixture.productID
        )
        let candidate = try #require(contract.candidates.first(where: {
            $0.garmentTypeCode == "polo_shirt"
        }))
        let mutationID = UUID()

        let result = try await coordinator.setUserProductClassification(
            contract: contract,
            candidate: candidate,
            expectedRevision: 0,
            mutationID: mutationID
        )
        let request = try #require(await remote.capturedSetRequest())

        #expect(result.effectiveClassification.isPersonalComparisonAuthority)
        #expect(request.productID == fixture.productID)
        #expect(request.selectedCandidateFingerprint == candidate.candidateFingerprint)
        #expect(request.expectedCandidateSetHash == contract.candidateSetHash)
        #expect(request.expectedProductInputFingerprint == contract.productInputFingerprint)
        #expect(request.expectedProductEvidenceFingerprint == contract.productEvidenceFingerprint)
        #expect(request.expectedRevision == 0)
        #expect(request.mutationID == mutationID)
        #expect(await remote.setCallCount() == 1)

        let clearMutationID = UUID()
        let cleared = try await coordinator.clearUserProductClassification(
            productID: fixture.productID,
            expectedRevision: 1,
            mutationID: clearMutationID
        )
        let clearRequest = try #require(await remote.capturedClearRequest())
        #expect(cleared.cleared == true)
        #expect(!cleared.effectiveClassification.isPersonalComparisonAuthority)
        #expect(clearRequest.productID == fixture.productID)
        #expect(clearRequest.expectedRevision == 1)
        #expect(clearRequest.mutationID == clearMutationID)
    }

    @Test func coordinatorRejectsClientCandidateOutsideServerContractBeforeMutation() async throws {
        let fixture = try RecoveryContractFixture()
        let remote = RecoveryTransportStub(
            contract: fixture.contract,
            saved: fixture.savedMutation,
            cleared: fixture.clearedMutation
        )
        let coordinator = FitMatchServerAuthorityCoordinator(remote: remote)
        let forged: VNextClassificationRecoveryCandidateDTO = try decodeRecoveryJSON(
            """
            {
              "candidate_id":"forged","candidate_fingerprint":"forged",
              "display_name":"후드","category_code":"tops",
              "garment_type_code":"hoodie","sleeve_length_code":"long_sleeve",
              "comparison_policy_code":"hoodie"
            }
            """
        )

        var rejected = false
        do {
            _ = try await coordinator.setUserProductClassification(
                contract: fixture.contract,
                candidate: forged,
                expectedRevision: 0
            )
        } catch let error as FitMatchServerAuthorityError {
            rejected = error == .invalidClassificationRecoveryContract(
                "candidate_not_in_server_contract"
            )
        }

        #expect(rejected)
        #expect(await remote.setCallCount() == 0)
    }

    @Test func snapshotV4PreservesPersonalProjectionAsImmutableJSONEvidence() throws {
        let productID = UUID()
        let variantID = UUID()
        let overrideID = UUID()
        let snapshot: VNextComparisonBeginSnapshotDTO = try decodeRecoveryJSON(
            """
            {
              "snapshot_schema_version":4,
              "target_snapshot":{
                "product_id":"\(productID)","variant_id":"\(variantID)",
                "authorized_candidate_product_size_ids":[],
                "classification_status":"CONFIRMED",
                "garment_type_code":"polo_shirt","sleeve_length_code":"short_sleeve",
                "candidates":[]
              },
              "policy_snapshot":{"metrics":[]},
              "authorization_snapshot":{
                "decision":"AUTOMATIC","allowed":true,"mode":"AUTOMATIC"
              },
              "excluded_measurement_codes":[],
              "reference_snapshot":{},
              "authority_snapshot":{
                "personal_projection_at_begin":{
                  "override_id":"\(overrideID)","revision":1,
                  "classification_source":"USER_EXPLICIT",
                  "selected_candidate_fingerprint":"candidate-polo",
                  "candidate_contract_version":"recovery-v1",
                  "candidate_set_hash":"candidate-set-v1"
                },
                "effective_classification_at_begin":{
                  "source":"USER_EXPLICIT","garment_type_code":"polo_shirt"
                }
              },
              "input_snapshot":{
                "effective_authority_fingerprint":"effective-v1",
                "personal_override_revision":1
              }
            }
            """
        )

        let authority = try #require(snapshot.authoritySnapshot.objectValue)
        let personal = try #require(
            authority["personal_projection_at_begin"]?.objectValue
        )
        let effective = try #require(
            authority["effective_classification_at_begin"]?.objectValue
        )
        #expect(snapshot.snapshotSchemaVersion == 4)
        #expect(personal["override_id"]?.stringValue == overrideID.uuidString)
        #expect(personal["classification_source"]?.stringValue == "USER_EXPLICIT")
        #expect(effective["garment_type_code"]?.stringValue == "polo_shirt")
    }
}

private struct RecoveryContractFixture {
    let productID: UUID
    let overrideID: UUID
    let contract: VNextClassificationRecoveryContractDTO
    let savedMutation: VNextUserClassificationMutationDTO
    let clearedMutation: VNextUserClassificationMutationDTO

    init() throws {
        let productID = UUID()
        let overrideID = UUID()
        self.productID = productID
        self.overrideID = overrideID
        contract = try decodeRecoveryJSON(
            """
            {
              "product_id":"\(productID)","global_status":"REVIEW_REQUIRED",
              "recoverability":"RECOVERABLE","unrecoverable_reason":null,
              "fixed_facts":{
                "audience_code":"MEN","product_structure_code":"SINGLE",
                "category_code":"tops","sleeve_length_code":"short_sleeve"
              },
              "unknown_fields":["garment_type"],
              "candidates":[
                {
                  "candidate_id":"candidate-tshirt","candidate_fingerprint":"candidate-tshirt",
                  "display_name":"티셔츠","category_code":"tops",
                  "garment_type_code":"tshirt","sleeve_length_code":"short_sleeve",
                  "comparison_policy_code":"tshirt"
                },
                {
                  "candidate_id":"candidate-polo","candidate_fingerprint":"candidate-polo",
                  "display_name":"폴로","category_code":"tops",
                  "garment_type_code":"polo_shirt","sleeve_length_code":"short_sleeve",
                  "comparison_policy_code":"polo_shirt"
                },
                {
                  "candidate_id":"candidate-shirt","candidate_fingerprint":"candidate-shirt",
                  "display_name":"셔츠","category_code":"tops",
                  "garment_type_code":"shirt_blouse","sleeve_length_code":"short_sleeve",
                  "comparison_policy_code":"shirt_blouse"
                }
              ],
              "candidate_count":3,"product_input_fingerprint":"input-v1",
              "product_evidence_fingerprint":"evidence-v1","resolver_version":"resolver-v2",
              "candidate_contract_version":"recovery-v1","candidate_set_hash":"set-v1",
              "current_review_reason":"Product-exact verified evidence is required"
            }
            """
        )
        savedMutation = try decodeRecoveryJSON(
            """
            {
              "saved":true,"idempotent":false,"event":"SELECTED",
              "override":{
                "id":"\(overrideID)","product_id":"\(productID)",
                "classification_source":"USER_EXPLICIT","audience_code":"MEN",
                "category_code":"tops","garment_type_code":"polo_shirt",
                "comparison_policy_code":"polo_shirt","sleeve_length_code":"short_sleeve",
                "selected_candidate_fingerprint":"candidate-polo",
                "candidate_contract_version":"recovery-v1","candidate_set_hash":"set-v1",
                "revision":1,"cleared_at":null
              },
              "effective_classification":{
                "product_id":"\(productID)","state":"PERSONAL_CONFIRMED",
                "classification_status":"CONFIRMED","effective_source":"USER_EXPLICIT",
                "category_code":"tops","garment_type_code":"polo_shirt",
                "audience_code":"MEN","sleeve_length_code":"short_sleeve",
                "comparison_policy_code":"polo_shirt","product_structure_code":"SINGLE",
                "override_revision":1,"effective_authority_fingerprint":"effective-v1",
                "effective_contract_version":"effective-v1"
              }
            }
            """
        )
        clearedMutation = try decodeRecoveryJSON(
            """
            {
              "cleared":true,"idempotent":false,"override_id":"\(overrideID)",
              "revision":2,
              "effective_classification":{
                "product_id":"\(productID)","state":"REVIEW_REQUIRED",
                "classification_status":"REVIEW_REQUIRED","effective_source":"NONE",
                "audience_code":"MEN","product_structure_code":"SINGLE",
                "effective_authority_fingerprint":"effective-v2",
                "effective_contract_version":"effective-v1"
              }
            }
            """
        )
    }
}

private actor RecoveryTransportStub: FitMatchServerAuthorityRemoteServicing {
    private let contract: VNextClassificationRecoveryContractDTO
    private let saved: VNextUserClassificationMutationDTO
    private let cleared: VNextUserClassificationMutationDTO
    private var setRequests: [FitMatchSetUserProductClassificationRequest] = []
    private var clearRequests: [FitMatchClearUserProductClassificationRequest] = []

    init(
        contract: VNextClassificationRecoveryContractDTO,
        saved: VNextUserClassificationMutationDTO,
        cleared: VNextUserClassificationMutationDTO
    ) {
        self.contract = contract
        self.saved = saved
        self.cleared = cleared
    }

    func classificationRecoveryOptions(productID: UUID) async throws
        -> VNextClassificationRecoveryContractDTO {
        contract
    }

    func setUserProductClassification(
        _ request: FitMatchSetUserProductClassificationRequest
    ) async throws -> VNextUserClassificationMutationDTO {
        setRequests.append(request)
        return saved
    }

    func clearUserProductClassification(
        _ request: FitMatchClearUserProductClassificationRequest
    ) async throws -> VNextUserClassificationMutationDTO {
        clearRequests.append(request)
        return cleared
    }

    func capturedSetRequest() -> FitMatchSetUserProductClassificationRequest? {
        setRequests.last
    }

    func capturedClearRequest() -> FitMatchClearUserProductClassificationRequest? {
        clearRequests.last
    }

    func setCallCount() -> Int { setRequests.count }

    func resolve(_ request: FitMatchProductResolutionRequest) async throws
        -> FitMatchProductResolutionResponse { throw StubError.unexpected }

    func submitProductObservation(_ request: FitMatchProductObservationRequest) async throws
        -> FitMatchProductObservationResponse { throw StubError.unexpected }

    func fetchProductRuntime(_ request: FitMatchProductResolutionRequest) async throws
        -> FitMatchProductRuntimeResponse { throw StubError.unexpected }

    func listClosetItems() async throws -> FitMatchClosetItemsResponse {
        .init(state: "ready", items: [])
    }

    func findReferenceCandidates(targetProductID: UUID) async throws
        -> FitMatchReferenceCandidatesResponse { throw StubError.unexpected }

    private enum StubError: Error { case unexpected }
}

private func decodeRecoveryJSON<T: Decodable>(_ json: String) throws -> T {
    try JSONDecoder().decode(T.self, from: Data(json.utf8))
}
