import Foundation

enum ProductMeasurementAvailability: String, Equatable {
    case actualMeasurements
    case standardSizeChart
    case unavailable
}

enum ProductComparisonMode: String, Equatable {
    case actualMeasurements
    case standardSizeFallback
    case unavailable
}

enum ProductAnalysisPhase: Int, Equatable {
    case loadingProductInfo
    case loadingSizeChart
    case preparingComparison
}

/// A typed, user-recoverable parser state. This must never be inferred from
/// retailer display copy or an error string in the comparison UI.
enum ProductAnalysisRecoveryAction: String, Equatable {
    case confirmCategoryBeforeMeasurements
    case enterMeasurementsManually
}

enum StandardBodySizeChart {
    static let metadataMarker = "fitmatch_standard_size_chart"
    static let unavailableMarker = "fitmatch_size_unavailable"

    static func normalizedSize(from optionName: String) -> String? {
        let uppercased = optionName.uppercased()
        // ICU on physical iOS devices rejects lookbehind in this API even
        // though the same expression can pass macOS-hosted tests.
        let pattern = #"(?:^|[^A-Z0-9])(XXL|XL|XS|L|M|S)(?![A-Z])"#
        if let regex = try? NSRegularExpression(pattern: pattern) {
            let matches = regex.matches(
                in: uppercased,
                range: NSRange(uppercased.startIndex..<uppercased.endIndex, in: uppercased)
            )
            guard matches.count <= 1 else {
                // A set option such as "브라_S 팬티_L" must not be interpreted
                // as one garment's body-chest standard size.
                return nil
            }
            if let match = matches.first,
           let range = Range(match.range(at: 1), in: uppercased) {
                return String(uppercased[range])
            }
        }

        let circumferencePattern = #"(?:44|55|66|77|88|110)\s*\((85|90|95|100|105|110)\)"#
        guard let regex = try? NSRegularExpression(pattern: circumferencePattern),
              let match = regex.firstMatch(
                in: uppercased,
                range: NSRange(uppercased.startIndex..<uppercased.endIndex, in: uppercased)
              ),
              let range = Range(match.range(at: 1), in: uppercased),
              let circumference = Double(uppercased[range]) else {
            return nil
        }
        return sizeName(for: circumference)
    }

    static func chestCircumferenceCm(for optionName: String) -> Double? {
        guard let size = normalizedSize(from: optionName) else { return nil }
        return ["XS": 85, "S": 90, "M": 95, "L": 100, "XL": 105, "XXL": 110][size]
    }

    private static func sizeName(for circumference: Double) -> String? {
        [85: "XS", 90: "S", 95: "M", 100: "L", 105: "XL", 110: "XXL"][circumference]
    }
}

struct ParsedProductInfo {
    var sourceURL: URL
    var sourceType: ProductSourceType = .manual
    var sourceName: String = "직접 입력"
    var brandName: String
    var productName: String
    var category: ClothingCategory
    var detailCategory: ClosetDetailCategory
    var sizes: [ParsedProductSize]
    var parserNotice: String? = nil
    var productID: String? = nil
    var imageURLString: String? = nil
    var price: Int? = nil
    var canonicalURLString: String? = nil
    var sourceCategoryPath: String? = nil
    var sourceCategoryDepth1: String? = nil
    var sourceCategoryDepth2: String? = nil
    var sourceCategoryDepth3: String? = nil
    var sourceCategoryDepth4: String? = nil
    var productTargetGender: UserGender = .unknown
    var productMetadata: ProductMetadata = ProductMetadata()
    var measurementAvailability: ProductMeasurementAvailability = .actualMeasurements
    var sizeTableRecoveryContext: SizeTableRecoveryContext? = nil
    var parserProvenance: ProductParserProvenance? = nil
    var recoveryAction: ProductAnalysisRecoveryAction? = nil
}

/// Describes where the product facts came from without changing their runtime meaning.
///
/// Measurement-level provenance remains on `ParsedMeasurement`. This envelope records
/// which retailer parser produced the product facts so backend observations can be
/// audited without inferring a parser from display copy such as `sourceName`.
struct ProductParserProvenance: Equatable {
    static let contractVersion = "ios-parser-provenance-v1"

    var parserCode: String
    var parserVersion: String?
    var fieldSources: [String: String]
}

extension ParsedProductInfo {
    func recordingParserProvenance(
        parserCode: String,
        parserVersion: String? = nil
    ) -> ParsedProductInfo {
        var copy = self
        var fieldSources: [String: String] = [
            "source_url": "user_supplied_url",
            "product_name": "retailer_parser",
            "brand_name": "retailer_parser",
            "category": "ios_parser_classification",
            "detail_category": "ios_parser_classification"
        ]
        if productID?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false {
            fieldSources["product_id"] = "retailer_parser"
        }
        if sourceCategoryPath?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false {
            fieldSources["source_category_path"] = "retailer_parser"
        }
        let sourceCategoryCodes = [
            productMetadata.categoryDepth1Code,
            productMetadata.categoryDepth2Code,
            productMetadata.categoryDepth3Code,
            productMetadata.categoryDepth4Code
        ].compactMap { $0?.trimmingCharacters(in: .whitespacesAndNewlines) }
        if sourceCategoryCodes.contains(where: { !$0.isEmpty }) {
            fieldSources["source_category_codes"] = "retailer_parser"
        }
        if productTargetGender != .unknown || !productMetadata.genderCodes.isEmpty {
            fieldSources["audience"] = "retailer_parser"
        }
        if !sizes.isEmpty {
            fieldSources["sizes"] = "retailer_parser"
        }
        if sizes.contains(where: { !$0.measurementRecords.isEmpty }) {
            fieldSources["measurements"] = "measurement_records.evidence"
        }
        if imageURLString?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false {
            fieldSources["image_url"] = "retailer_parser"
        }
        if price != nil {
            fieldSources["price"] = "retailer_parser"
        }
        if canonicalURLString?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false {
            fieldSources["canonical_url"] = "retailer_parser"
        }
        copy.parserProvenance = ProductParserProvenance(
            parserCode: parserCode,
            parserVersion: parserVersion,
            fieldSources: fieldSources
        )
        return copy
    }
}

struct ParsedProductSize: Identifiable, Equatable {
    var id = UUID()
    var name: String
    var measurements: GarmentMeasurements
    var measurementRecords: [ParsedMeasurement] = []
    var standardBodyChestCircumferenceCm: Double? = nil
    /// Retailer fact only. Parsers must leave this nil when the retailer did
    /// not expose size-level stock evidence; nil is encoded as UNKNOWN.
    var availabilityStatus: String? = nil
    var availabilityObservedAt: Date? = nil
    var availabilityValidUntil: Date? = nil
    var availabilityEvidence: [String: String] = [:]
}

struct ParsedMeasurement: Equatable {
    var value: Double
    var unit: MeasurementUnit = .centimeter
    var measurementCode: MeasurementCode
    var displayKind: MeasurementDisplayKind
    var methodSource: String
    var methodProfile: String? = nil
    var inputSource: MeasurementInputSource
    var standardVersion: String? = nil
    var mappingVersion: String = "measurement_mapping_v1"
    var rawCode: String? = nil
    var rawLabel: String
    var rawInfo: String? = nil
    var rawValueText: String? = nil
    var evidenceLevel: MeasurementEvidenceLevel
    var semanticStatus: MeasurementSemanticStatus

    func makeRecord(productSize: ProductSize? = nil, userFit: UserFit? = nil) -> GarmentMeasurementRecord {
        GarmentMeasurementRecord(
            value: value,
            unit: unit,
            measurementCode: measurementCode,
            displayKind: displayKind,
            methodSource: methodSource,
            methodProfile: methodProfile,
            inputSource: inputSource,
            standardVersion: standardVersion,
            mappingVersion: mappingVersion,
            rawCode: rawCode,
            rawLabel: rawLabel,
            rawInfo: rawInfo,
            rawValueText: rawValueText,
            evidenceLevel: evidenceLevel,
            semanticStatus: semanticStatus,
            productSize: productSize,
            userFit: userFit
        )
    }
}

extension ParsedProductSize {
    static func stableID(for sizeName: String) -> UUID {
        let normalizedName = sizeName
            .split(separator: "|", omittingEmptySubsequences: false)
            .map { ParsedProductSizeNormalizer.normalizedSizeKey(for: String($0)) }
            .joined(separator: "|")
        let seed = normalizedName.isEmpty ? sizeName : normalizedName
        let bytes = Array(seed.utf8)
        var firstHash: UInt64 = 14_695_981_039_346_656_037
        var secondHash: UInt64 = 10_995_116_282_11

        for byte in bytes {
            firstHash ^= UInt64(byte)
            firstHash &*= 1_099_511_628_211
        }

        for byte in bytes.reversed() {
            secondHash ^= UInt64(byte)
            secondHash &*= 1_099_511_628_211
        }

        var uuidBytes = [UInt8](repeating: 0, count: 16)
        for index in 0..<8 {
            uuidBytes[index] = UInt8((firstHash >> UInt64(index * 8)) & 0xff)
            uuidBytes[index + 8] = UInt8((secondHash >> UInt64(index * 8)) & 0xff)
        }
        uuidBytes[6] = (uuidBytes[6] & 0x0f) | 0x50
        uuidBytes[8] = (uuidBytes[8] & 0x3f) | 0x80

        return UUID(uuid: (
            uuidBytes[0], uuidBytes[1], uuidBytes[2], uuidBytes[3],
            uuidBytes[4], uuidBytes[5], uuidBytes[6], uuidBytes[7],
            uuidBytes[8], uuidBytes[9], uuidBytes[10], uuidBytes[11],
            uuidBytes[12], uuidBytes[13], uuidBytes[14], uuidBytes[15]
        ))
    }
}

enum ParsedProductSizeNormalizer {
    static func normalizedSizeKey(for name: String) -> String {
        SizeTokenNormalizer.normalizedKey(for: name)
    }

    static func uniqueSizes(_ sizes: [ParsedProductSize]) -> [ParsedProductSize] {
        var seenKeys = Set<String>()
        var uniqueSizes: [ParsedProductSize] = []

        for size in sizes {
            let key = normalizedSizeKey(for: size.name)
            guard !key.isEmpty, !seenKeys.contains(key) else {
                continue
            }

            seenKeys.insert(key)
            uniqueSizes.append(size)
        }

        return uniqueSizes
    }

    static func uniqueProductSizes(_ sizes: [ProductSize]) -> [ProductSize] {
        var seenKeys = Set<String>()
        var uniqueSizes: [ProductSize] = []

        for size in sizes {
            let key = normalizedSizeKey(for: size.name)
            guard !key.isEmpty, !seenKeys.contains(key) else {
                continue
            }

            seenKeys.insert(key)
            uniqueSizes.append(size)
        }

        return uniqueSizes
    }

    static func makeProductSizes(from sizes: [ParsedProductSize]) -> [ProductSize] {
        uniqueSizes(sizes).enumerated().map { index, size in
            let productSize = ProductSize(
                id: size.id,
                name: SizeTokenNormalizer.displayName(for: size.name),
                measurements: size.measurements,
                displayOrder: index
            )
            let records = size.measurementRecords.map { $0.makeRecord(productSize: productSize) }
            productSize.measurementRecords = records
            if !records.isEmpty {
                productSize.measurementSchemaVersion = 1
                productSize.measurementMigrationVersion = MeasurementLegacyBackfillService.migrationVersion
                productSize.measurementMigrationStatus = .completed
                productSize.measurementMigrationErrorCode = nil
            }
            return productSize
        }
    }
}

@MainActor
protocol ProductURLParsing {
    func canParse(_ url: URL) -> Bool
    func parse(from url: URL) async throws -> ParsedProductInfo
    func parse(
        from url: URL,
        onProgress: @escaping (ProductAnalysisPhase) -> Void
    ) async throws -> ParsedProductInfo
}

@MainActor
protocol ZARACategoryResumableParsing: ProductURLParsing {
    func parse(
        from url: URL,
        confirmedCategory: ClothingCategory,
        confirmedDetailCategory: ClosetDetailCategory,
        onProgress: @escaping (ProductAnalysisPhase) -> Void
    ) async throws -> ParsedProductInfo
}

extension ProductURLParsing {
    func parse(
        from url: URL,
        onProgress: @escaping (ProductAnalysisPhase) -> Void
    ) async throws -> ParsedProductInfo {
        try await parse(from: url)
    }
}

enum ProductURLParserError: LocalizedError {
    case invalidURL
    case unsupportedURL
    case automaticParsingUnavailable

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "올바른 상품 URL을 입력해 주세요."
        case .unsupportedURL:
            return "아직 지원하지 않는 상품 링크예요. 현재는 무신사, 유니클로, COS 상품 URL을 지원합니다."
        case .automaticParsingUnavailable:
            return "상품 정보를 불러오지 못했어요. 잠시 후 다시 시도하거나 지원하는 쇼핑몰의 상품 URL인지 확인해 주세요."
        }
    }
}

struct ProductURLParserPartialError: LocalizedError {
    let productInfo: ParsedProductInfo

    var errorDescription: String? {
        "상품 정보 일부만 불러왔어요. 사이즈 정보를 찾지 못했어요."
    }
}

enum ProductURLSupport {
    static func normalizedURL(from rawValue: String) -> URL? {
        let trimmed = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            return nil
        }

        let candidate = extractedURLString(from: trimmed) ?? trimmed
        let normalizedCandidate = candidate.hasPrefix("http://") || candidate.hasPrefix("https://")
            ? candidate
            : "https://\(candidate)"

        guard let url = URL(string: normalizedCandidate),
              let scheme = url.scheme?.lowercased(),
              ["http", "https"].contains(scheme),
              let host = url.host?.lowercased(),
              !host.isEmpty else {
            return nil
        }

        return url
    }

    static func supportedProviderName(for urlString: String) -> String? {
        guard let url = normalizedURL(from: urlString) else {
            return nil
        }

        if isMusinsaURL(url) { return "무신사" }
        if isUniqloURL(url) { return "유니클로" }
        if isZARAURL(url), ZARAIntegrationAvailability.isEnabled { return "ZARA" }
        if isCOSURL(url) { return "COS" }

        return nil
    }

    static func isSupportedProductURL(_ urlString: String) -> Bool {
        supportedProviderName(for: urlString) != nil
    }

    static func isMusinsaURL(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        return matches(host: host, domain: "musinsa.com")
            || host == "musinsa.onelink.me"
    }

    static func isUniqloURL(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        return matches(host: host, domain: "uniqlo.com")
    }

    static func isCOSURL(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        return matches(host: host, domain: "cos.com")
    }

    static func isZARAURL(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        return matches(host: host, domain: "zara.com")
    }

    private static func matches(host: String, domain: String) -> Bool {
        host == domain || host.hasSuffix(".\(domain)")
    }

    static func extractedURLString(from text: String) -> String? {
        let pattern = #"(https?://)?[^\s]*(musinsa|uniqlo|zara|cos)[^\s]*"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..<text.endIndex, in: text)),
              let range = Range(match.range, in: text) else {
            return nil
        }

        return String(text[range])
            .trimmingCharacters(in: CharacterSet(charactersIn: " \n\t\"'<>"))
    }
}

@MainActor
struct ProductURLParserService {
    private let musinsaParser: ProductURLParsing
    private let uniqloParser: ProductURLParsing
    private let zaraParser: ProductURLParsing
    private let cosParser: ProductURLParsing

    init(
        musinsaParser: ProductURLParsing? = nil,
        uniqloParser: ProductURLParsing? = nil,
        zaraParser: ProductURLParsing? = nil,
        cosParser: ProductURLParsing? = nil
    ) {
        self.musinsaParser = musinsaParser ?? MusinsaParser()
        self.uniqloParser = uniqloParser ?? UniqloParser()
        self.zaraParser = zaraParser ?? ZARAParser()
        self.cosParser = cosParser ?? COSParser()
    }

    func parse(
        urlString: String,
        onProgress: @escaping (ProductAnalysisPhase) -> Void = { _ in }
    ) async throws -> ParsedProductInfo {
        guard let url = ProductURLSupport.normalizedURL(from: urlString) else {
            throw ProductURLParserError.invalidURL
        }
        onProgress(.loadingProductInfo)

        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("-fitmatchAmbiguousCategoryFixture") {
            return Self.ambiguousCategoryFixture(for: url)
        }
        if ProcessInfo.processInfo.arguments.contains("-fitmatchOnboardingFixtures") {
            return Self.onboardingFixture(for: url)
        }
        #endif

        let isMusinsaURL = ProductURLSupport.isMusinsaURL(url)
        let isUniqloURL = uniqloParser.canParse(url)
        let isZARAURL = zaraParser.canParse(url)
        let isCOSURL = cosParser.canParse(url)
        let detectedProvider = isMusinsaURL ? "musinsa" : (isUniqloURL ? "uniqlo" : (isZARAURL ? "zara" : (isCOSURL ? "cos" : "generic")))
        #if DEBUG
        FitMatchDebugLogger.detail(screen: "상품 분석", action: "파서 선택", details: "파서=\(detectedProvider)")
        #endif

        if isMusinsaURL {
            do {
                return logParsedProductInfo((
                    try await musinsaParser.parse(from: url, onProgress: onProgress)
                ).normalizedSizes().recordingParserProvenance(parserCode: "musinsa"))
            } catch let partialError as ProductURLParserPartialError {
                #if DEBUG
                FitMatchDebugLogger.event(screen: "상품 분석", action: "무신사 파싱", state: "일부 성공", details: "오류=\(partialError.localizedDescription)")
                #endif
                throw ProductURLParserPartialError(
                    productInfo: partialError.productInfo
                        .normalizedSizes()
                        .recordingParserProvenance(parserCode: "musinsa")
                )
            } catch {
                if Task.isCancelled { throw CancellationError() }
                #if DEBUG
                FitMatchDebugLogger.event(screen: "상품 분석", action: "무신사 파싱", state: "실패", details: "오류=\(error.localizedDescription)")
                #endif
                throw ProductURLParserError.automaticParsingUnavailable
            }
        }

        if isUniqloURL {
            do {
                return logParsedProductInfo((
                    try await uniqloParser.parse(from: url, onProgress: onProgress)
                ).normalizedSizes().recordingParserProvenance(parserCode: "uniqlo_kr"))
            } catch let partialError as ProductURLParserPartialError {
                #if DEBUG
                FitMatchDebugLogger.event(screen: "상품 분석", action: "유니클로 파싱", state: "일부 성공", details: "오류=\(partialError.localizedDescription)")
                #endif
                throw ProductURLParserPartialError(
                    productInfo: partialError.productInfo
                        .normalizedSizes()
                        .recordingParserProvenance(parserCode: "uniqlo_kr")
                )
            } catch {
                if Task.isCancelled { throw CancellationError() }
                #if DEBUG
                FitMatchDebugLogger.event(screen: "상품 분석", action: "유니클로 파싱", state: "실패", details: "오류=\(error.localizedDescription)")
                #endif
                throw ProductURLParserError.automaticParsingUnavailable
            }
        }

        if isZARAURL {
            guard ZARAIntegrationAvailability.isEnabled else {
                throw ProductURLParserError.unsupportedURL
            }
            do {
                return logParsedProductInfo((
                    try await zaraParser.parse(from: url, onProgress: onProgress)
                ).normalizedSizes().recordingParserProvenance(parserCode: "zara_kr"))
            } catch let partialError as ProductURLParserPartialError {
                #if DEBUG
                FitMatchDebugLogger.event(screen: "상품 분석", action: "ZARA 파싱", state: "일부 성공", details: "오류=\(partialError.localizedDescription)")
                #endif
                throw ProductURLParserPartialError(
                    productInfo: partialError.productInfo
                        .normalizedSizes()
                        .recordingParserProvenance(parserCode: "zara_kr")
                )
            } catch {
                if Task.isCancelled { throw CancellationError() }
                #if DEBUG
                FitMatchDebugLogger.event(screen: "상품 분석", action: "ZARA 파싱", state: "실패", details: "오류=\(error.localizedDescription)")
                #endif
                throw ProductURLParserError.automaticParsingUnavailable
            }
        }

        if isCOSURL {
            do {
                return logParsedProductInfo((
                    try await cosParser.parse(from: url, onProgress: onProgress)
                ).normalizedSizes().recordingParserProvenance(parserCode: "cos_kr"))
            } catch let partialError as ProductURLParserPartialError {
                #if DEBUG
                FitMatchDebugLogger.event(screen: "상품 분석", action: "COS 파싱", state: "일부 성공", details: "오류=\(partialError.localizedDescription)")
                #endif
                throw ProductURLParserPartialError(
                    productInfo: partialError.productInfo
                        .normalizedSizes()
                        .recordingParserProvenance(parserCode: "cos_kr")
                )
            } catch {
                if Task.isCancelled { throw CancellationError() }
                #if DEBUG
                FitMatchDebugLogger.event(screen: "상품 분석", action: "COS 파싱", state: "실패", details: "오류=\(error.localizedDescription)")
                #endif
                throw ProductURLParserError.automaticParsingUnavailable
            }
        }

        throw ProductURLParserError.unsupportedURL
    }

    /// Continues a fail-closed ZARA import after the user explicitly chooses
    /// the garment category. Other retailers and generic parsers cannot enter
    /// this retailer-specific recovery capability by accident.
    func resumeZARAParsing(
        urlString: String,
        confirmedCategory: ClothingCategory,
        confirmedDetailCategory: ClosetDetailCategory,
        onProgress: @escaping (ProductAnalysisPhase) -> Void = { _ in }
    ) async throws -> ParsedProductInfo {
        guard let url = ProductURLSupport.normalizedURL(from: urlString),
              ProductURLSupport.isZARAURL(url),
              confirmedCategory != .other,
              confirmedDetailCategory != .other,
              let parser = zaraParser as? any ZARACategoryResumableParsing else {
            throw ProductURLParserError.automaticParsingUnavailable
        }
        // The release gate is enforced on the initial URL parse. This method
        // is only reachable from the typed recovery state produced by that
        // parse, and keeping it independently testable prevents a string- or
        // retailer-name-based UI workaround.

        do {
            return logParsedProductInfo((
                try await parser.parse(
                    from: url,
                    confirmedCategory: confirmedCategory,
                    confirmedDetailCategory: confirmedDetailCategory,
                    onProgress: onProgress
                )
            ).normalizedSizes().recordingParserProvenance(parserCode: "zara_kr"))
        } catch let partialError as ProductURLParserPartialError {
            throw ProductURLParserPartialError(
                productInfo: partialError.productInfo
                    .normalizedSizes()
                    .recordingParserProvenance(parserCode: "zara_kr")
            )
        }
    }

    #if DEBUG
    private static func ambiguousCategoryFixture(for url: URL) -> ParsedProductInfo {
        let isSiblingProduct = url.lastPathComponent.contains("sibling")
        return ParsedProductInfo(
            sourceURL: url,
            sourceType: .marketplace,
            sourceName: "무신사",
            brandName: "분류 검증 브랜드",
            productName: isSiblingProduct
                ? "같은 경로의 다른 모호 상품"
                : "모호한 카테고리 UI 검증 상품",
            category: .top,
            detailCategory: .other,
            sizes: [ParsedProductSize(
                name: "M",
                measurements: GarmentMeasurements(
                    shoulder: 48,
                    chest: 54,
                    totalLength: 70,
                    sleeveLength: 24
                )
            )],
            productID: isSiblingProduct
                ? "fitmatch-ambiguous-category-ui-sibling"
                : "fitmatch-ambiguous-category-ui",
            sourceCategoryPath: "스포츠/레저 > 상의 > 기타상의",
            sourceCategoryDepth1: "스포츠/레저",
            sourceCategoryDepth2: "상의",
            sourceCategoryDepth3: "기타상의",
            productTargetGender: .unisex
        )
    }
    #endif

    private func logParsedProductInfo(_ productInfo: ParsedProductInfo) -> ParsedProductInfo {
        #if DEBUG
        FitMatchDebugLogger.detail(
            screen: "상품 분석",
            action: "파싱 결과",
            details: "성별=\(productInfo.productTargetGender.rawValue), depth1=\(productInfo.sourceCategoryDepth1 ?? "없음"), depth2=\(productInfo.sourceCategoryDepth2 ?? "없음"), depth3=\(productInfo.sourceCategoryDepth3 ?? "없음"), depth4=\(productInfo.sourceCategoryDepth4 ?? "없음"), 경로=\(productInfo.sourceCategoryPath ?? "없음")"
        )
        #endif
        return productInfo
    }

    private func normalizedURL(from rawValue: String) -> URL? {
        ProductURLSupport.normalizedURL(from: rawValue)
    }

    private func extractedURLString(from text: String) -> String? {
        ProductURLSupport.extractedURLString(from: text)
    }

    #if DEBUG
    private static func onboardingFixture(for url: URL) -> ParsedProductInfo {
        let isMusinsa = ProductURLSupport.isMusinsaURL(url)
        let provider = isMusinsa ? "musinsa" : "uniqlo_kr"
        let measurements = GarmentMeasurements(
            shoulder: 48,
            chest: 54,
            totalLength: 70,
            sleeveLength: 24
        )
        let records: [(Double, MeasurementCode, MeasurementDisplayKind, String)] = [
            (48, .shoulderWidthSeamToSeam, .shoulder, "어깨너비"),
            (54, .chestWidthPitToPit, .chest, "가슴단면"),
            (70, .bodyLengthBackNeckToHem, .totalLength, "총장"),
            (24, .sleeveShoulderSeamToCuff, .sleeveLength, "소매길이")
        ]
        let size = ParsedProductSize(
            name: "M",
            measurements: measurements,
            measurementRecords: records.map { value, code, kind, label in
                ParsedMeasurement(
                    value: value,
                    measurementCode: code,
                    displayKind: kind,
                    methodSource: provider,
                    methodProfile: isMusinsa ? "musinsa_type_6" : "uniqlo_official_top",
                    inputSource: .importedSizeChart,
                    rawCode: code.rawValue,
                    rawLabel: label,
                    rawValueText: String(value),
                    evidenceLevel: .officialText,
                    semanticStatus: .mapped
                )
            }
        )
        let sourcePath = isMusinsa ? "상의 > 반소매 티셔츠" : "상의 > 티셔츠 > 반팔"
        return ParsedProductInfo(
            sourceURL: url,
            sourceType: isMusinsa ? .marketplace : .officialStore,
            sourceName: isMusinsa ? "무신사" : "유니클로 공식몰",
            brandName: isMusinsa ? "온보딩 무신사 브랜드" : "유니클로",
            productName: isMusinsa ? "온보딩 무신사 기준옷" : "온보딩 유니클로 기준옷",
            category: .top,
            detailCategory: .shortSleeve,
            sizes: [size],
            productID: isMusinsa ? "onboarding-musinsa" : "E000001",
            canonicalURLString: url.absoluteString,
            sourceCategoryPath: sourcePath,
            sourceCategoryDepth1: "상의",
            sourceCategoryDepth2: isMusinsa ? "반소매 티셔츠" : "티셔츠",
            sourceCategoryDepth3: isMusinsa ? nil : "반팔",
            productTargetGender: .unisex,
            productMetadata: ProductMetadata(
                sourceCategoryPath: sourcePath,
                sourceCategoryDepth1: "상의",
                sourceCategoryDepth2: isMusinsa ? "반소매 티셔츠" : "티셔츠",
                sourceCategoryDepth3: isMusinsa ? nil : "반팔",
                genderCodes: [UserGender.unisex.rawValue]
            )
        )
    }
    #endif
}

extension ParsedProductInfo {
    func normalizedSizes() -> ParsedProductInfo {
        var copy = self
        copy.sizes = ParsedProductSizeNormalizer.uniqueSizes(sizes)
        let shouldInferLengthDetail = copy.detailCategory == .other
        if shouldInferLengthDetail {
            let length = GarmentLengthInferencePolicy.infer(
                category: copy.category,
                gender: copy.productTargetGender,
                samples: GarmentLengthInferencePolicy.samples(from: copy.sizes),
                fallbackMeasurements: copy.sizes.map(\.measurements)
            )
            if copy.category.serviceGroup == .top {
                if length == .short { copy.detailCategory = .shortSleeve }
                if length == .long { copy.detailCategory = .longSleeve }
            } else if copy.category.serviceGroup == .bottom {
                if length == .short { copy.detailCategory = .shorts }
                if length == .long { copy.detailCategory = .longPants }
            }
        }
        return copy
    }
}
